﻿namespace Bytewizer.TinyCLR.HelloWorld.Models
{
    public enum Gender
    {
        Male,
        Female
    }
}
